<template>
  <transition name="slide-fade" mode="out-in">
    <router-view />
  </transition>
</template>