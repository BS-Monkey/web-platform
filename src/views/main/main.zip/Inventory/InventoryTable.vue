<template>
  <div>
    <div>
      <div class="row cxs12">
        <div class="row cxs12">
          <div class="cb cxs1">
            <input id="cb1" name="cb1" type="checkbox" v-model="ec2Check" @click="checkedFun()"/>
            <label for="cb1" class="cb-texts">EC2 </label>
          </div>
          <div class="cb cxs1">
            <input id="cb2" name="cb2" type="checkbox" v-model="rdsCheck" @click="checkedFun()"/>
            <label for="cb2" class="cb-texts">RDS</label>
          </div>
          <div class="cb cxs1">
            <input id="cb3" name="cb3" type="checkbox" v-model="s3Check" @click="checkedFun()"/>
            <label for="cb3" class="cb-texts">S3</label>
          </div>
          <div class="cb cxs2">
            <input id="cb4" name="cb6" type="checkbox" v-model="cloudWatchCheck" @click="checkedFun()"/>
            <label for="cb4" class="cb-texts">Cloudwatch</label>
          </div>
          <div class="cb cxs2">
            <input id="cb5" name="cb6" type="checkbox" v-model="lambdaCheck" @click="checkedFun()"/>
            <label for="cb5" class="cb-texts">Lambda</label>
          </div>
          <div class="cb cxs2">
            <input id="cb6" name="cb6" type="checkbox" v-model="serviceTypeCheck" @click="checkedFun()"/>
            <label for="cb6" class="cb-texts">ServiceType</label>
          </div>
          <div class="cb cxs2">
            <input id="cb7" name="cb6" type="checkbox" v-model="regionCheck" @click="checkedFun()"/>
            <label for="cb7" class="cb-texts">Region</label>
          </div>
        </div>
      </div>
    </div>
    <br><br>
    <div>
      <div class="tree">
        <table border="1" class="styled-table" style="height:100px;overflow:auto;" width="100%">
          <thead style="background-color:hsl(192deg 71% 92%);">
            <tr>
              <!-- <th class="default">#</th> -->
              <th class="default" style="padding: 30px;">IntegrationID</th>
              <th class="default" style="padding: 30px">ResourceID</th>
              <!-- <th class="default" style="padding: 30px;">FirstSeen</th>
              <th class="default" style="padding: 30px;">LastSeen</th> -->
              <!-- <th class="default" style="padding: 30px">Region</th> -->
              <th class="default" style="padding: 30px">ServiceType</th>
              <!-- <th class="default" style="padding: 30px">Tags</th> -->
              <th class="default" style="padding: 30px">Metadata</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(user) in inventoryData" v-bind:key="user.email">
              <td style="padding-left: 20px; width: 30% !important;">
                <!-- <td style="padding-left: 20px" v-if="!user.role.includes('owner')">-->
                <!--class="button danger link" -->
                <span v-if="user.integration_id">{{ user.integration_id }}</span><span v-else>-</span>
              </td>
              <!--<td style="padding-left: 40px;" v-if="user.role.includes('owner')">-->
              <td style="padding-left: 40px; width: 30% !important;"><span v-if="user.resource_id">{{ user.resource_id }}</span><span v-else>-</span></td>
              <!-- <td style="padding-left: 40px; width: 80.66% !important;">{{ user.id }}</td> -->
              <!-- <td style="padding: 15px; width: 18% !important;"><span v-if="user.first_seen">{{ user.first_seen | dateTime }}</span><span v-else>-</span></td>
              <td style="padding: 15px; width: 18% !important;"><span v-if="user.last_seen">{{ user.last_seen | dateTime }}</span><span v-else>-</span></td>
              <td style="text-align:center;width: 7% !important;"><span v-if="user.region">{{ user.region }}</span><span v-else>-</span></td> -->
              <td style="text-align:center;width: 25% !important;"><span v-if="user.service_type">{{ user.service_type }}</span><span v-else>-</span></td>
              <td style="text-align:center;width: 20% !important;">
                <button v-if="user.metadata" @click="showMetadata(user.integration_id)">
                  show metadata
                </button>
                  <!-- <span v-for="val of user.metadata.Tags" v-bind:key="val.value">
                    <span class="tagContent" :title="val.Value">{{val.Value}}</span>
                  </span> -->
                <span v-else>
                -
                </span>
              </td>
              <!-- <td v-if="user.active" style="padding: 15px">
              {{ user.last_login | dateTime }}
            </td>
            <td v-else style="padding: 15px">
              -
              </td>-->
              <modal style="width: 100%" v-model="showModal">
                <h2>Metadata</h2>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Architectures</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Architectures">{{ metadata.Architectures[0] }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">CodeSha256</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.CodeSha256">{{ metadata.CodeSha256 }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">CodeSize</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.CodeSize">{{ metadata.CodeSize }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Description</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Description">{{ metadata.Description }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Environment</label>
                  </div>
                  <div class="cb cxs9">
                    <div v-if="metadata !== {} && metadata.Environment">
                      <label for="cb1" class="cb-texts">{{ metadata.Environment.Variables.DYNAMODB_TABLE_NAME }}</label><br />
                      <label for="cb1" class="cb-texts">{{ metadata.Environment.Variables.QUEUE_URL }}</label>
                    </div>
                    <div v-else>
                      <label for="cb1" class="cb-texts"> - </label><br />
                    </div>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">FunctionArn</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.FunctionArn">{{ metadata.FunctionArn }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">FunctionName</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.FunctionName">{{ metadata.FunctionName }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Handler</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Handler">{{ metadata.Handler }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">LastModified</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.LastModified">{{ metadata.LastModified }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">MemorySize</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.MemorySize">{{ metadata.MemorySize }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">PackageType</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.PackageType">{{ metadata.PackageType }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">RevisionId</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.RevisionId">{{ metadata.RevisionId }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Role</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Role">{{ metadata.Role }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Runtime</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Runtime">{{ metadata.Runtime }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Timeout</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Timeout">{{ metadata.Timeout }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">TracingConfig</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.TracingConfig">{{ metadata.TracingConfig.Mode }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
                <div class="row cxs12">
                  <div class="cb cxs3">
                    <label for="cb1" class="cb-texts">Version</label>
                  </div>
                  <div class="cb cxs9">
                    <label for="cb1" class="cb-texts" v-if="metadata !== {} && metadata.Version">{{ metadata.Version }}</label>
                    <label for="cb1" class="cb-texts" v-else> - </label>
                  </div>
                </div>
              </modal>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Vue, Watch, Component } from 'vue-property-decorator';
import API from '@/API';
import _ from 'lodash';
import './inventory.css';

@Component
export default class InventoryTable extends Vue {
  private inventoryData: any = [];
  private tempData: any = [];
  private assignData: any = [];
  private searchData: any = [];
  private ec2Check: boolean = false;
  private rdsCheck: boolean = false;
  private s3Check: boolean = false;
  private cloudWatchCheck: boolean = false;
  private lambdaCheck: boolean = false;
  private serviceTypeCheck: boolean = false;
  private regionCheck: boolean = false;
  private showRemoveModal: boolean = false;
  private searchText: string = '';
  private showModal: boolean = false;
  private metadata: any = [];
  private integrations: Array<Integration<All>> = [];

  get currentOrg(): string {
    return API.Organization_v2.getCurrentId();
  }

  private created(): void {
    this.getInventoryDetails();
    if (this.currentOrg) {
      this.getIntegrations();
    }
  }

  @Watch('currentOrg')
  private updateSelected() {
    this.getIntegrations();
  }

  private getIntegrations(): any {
    API.Integration.get().then((res) => {
      this.integrations = res;
      this.sort();
    });
  }

  @Watch('integrations')
  private sort(): void {
    console.log(this.integrations);
    this.integrations.forEach((x, i) => {
      // Hardcode threshold evaluator setting for now until we add new metadata to integrations
      if (x.definition_id === 'globe_billing') {
        this.integrations[i].metadata.threshold_evaluator = 'globe_billing';
      } else {
        const evaluator = 'alertsv2';
        this.integrations[i].metadata.threshold_evaluator = evaluator;
      }
    });
  }

  private showMetadata(integrationId: string): void {
    this.showModal = !this.showModal;
    const selectedInventory = this.inventoryData.find((data) => data.integration_id === integrationId);
    this.metadata = selectedInventory ? selectedInventory.metadata : {};
  }

  private checkedFun(): void {
    const ec2Check = document.getElementById('cb1') as HTMLInputElement;
    const rdsCheck = document.getElementById('cb2')  as HTMLInputElement;
    const s3Check = document.getElementById('cb3') as HTMLInputElement;
    const cloudWatchCheck = document.getElementById('cb4') as HTMLInputElement;
    const lambdaCheck = document.getElementById('cb5') as HTMLInputElement;
    const serviceTypeCheck = document.getElementById('cb6') as HTMLInputElement;
    const regionCheck = document.getElementById('cb7') as HTMLInputElement;
    this.assignData = [];
    if (ec2Check?.checked) { this.filterData('ec2_volumes'); }
    if (rdsCheck?.checked) { this.filterData('rds_db-snapshots'); }
    if (s3Check?.checked) { this.filterData('s3'); }
    if (cloudWatchCheck?.checked) { this.filterData('cloudwatch_alarms'); }
    if (lambdaCheck?.checked) { this.filterData('lambda_functions'); }
    if (serviceTypeCheck?.checked) { this.filterData('servicetype_functions'); }
    if (regionCheck?.checked) { this.filterData('region_functions'); }
    if (!ec2Check?.checked && !rdsCheck?.checked && !s3Check?.checked && !cloudWatchCheck?.checked && !lambdaCheck?.checked && !serviceTypeCheck?.checked && !regionCheck?.checked) {
      if (this.searchText === '') {
        this.inventoryData = this.tempData;
      } else {
        this.inventoryData = this.searchData;
      }
    } else {
      this.inventoryData = this.assignData;
    }
  }
  private filterData(serviceType): void {
    if (this.searchText === '') {
      _.filter(this.tempData, (item) => { if (item.service_type === serviceType) { this.assignData.push(item); } });
    } else {
      console.log(serviceType);
      _.filter(this.searchData, (item) => { if (item.service_type === serviceType) { this.assignData.push(item); } });
    }
  }

  @Watch('integrations')
  private getInventoryDetails(): void {
    console.log(this.integrations);
    if (this.integrations.length > 0) {
      API.Inventory.getInventory(this.integrations[0].id).then((response) => {
        console.log(response);
        /* tslint:disable:no-string-literal */
        this.inventoryData = response ? response : [];
        /* tslint:enable:no-string-literal */
        this.tempData = this.inventoryData;
      // this.inventoryData .sort((a: any, b: any) => a.email.localeCompare(b.email));
      // });
      });
    }
  }
  // /* Lifecycle
  // private created(): void {
  // }
  // }*/
}
</script>
<style lang="scss" scoped>
.item-texts div {
  line-height: 1.325;
  letter-spacing: 0.1rem;
  font-size: 1rem;
  padding-left: 1rem;
  padding: 6px;
  width: 10.89rem;
  border: 0.1rem solid var(--c-gray-500);
  font-size: 0.89rem;
}
.asset-untagged div {
  background: var(--c-info-400);
}
</style>